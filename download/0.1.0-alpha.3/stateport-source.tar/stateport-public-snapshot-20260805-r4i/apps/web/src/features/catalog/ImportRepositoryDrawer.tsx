/**
 * Import a local repository (catalog): discover allowlisted candidates,
 * inspect one read-only, review its exact identity and findings, then
 * register it with an explicit approval bound to the inspection digest.
 *
 * The flow never touches repository code: inspection is read-only on the
 * service, and registration binds the exact inspected identity — a stale
 * digest is rejected by the service and surfaced honestly here.
 */
import { CircleAlert, GitBranch, TriangleAlert } from 'lucide-react'
import { useCallback, useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'

import type { RepositoryCandidate, RepositoryInspection, RepositoryRegistration } from '@/client'
import { ClientError, getClient } from '@/client'
import { Drawer, ErrorState, InlineNotice, Spinner } from '@/components'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'

type Stage =
  | { kind: 'loading' }
  | { kind: 'error'; error: ClientError }
  | { kind: 'candidates'; candidates: RepositoryCandidate[] }
  | { kind: 'inspecting'; candidate: RepositoryCandidate }
  | { kind: 'review'; candidate: RepositoryCandidate; inspection: RepositoryInspection }
  | { kind: 'registering'; candidate: RepositoryCandidate; inspection: RepositoryInspection }
  | { kind: 'done'; registration: RepositoryRegistration; name: string }

export function ImportRepositoryDrawer({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const navigate = useNavigate()
  const [stage, setStage] = useState<Stage>({ kind: 'loading' })
  const [name, setName] = useState('')
  const [approved, setApproved] = useState(false)
  const [actionError, setActionError] = useState<string | null>(null)

  const [nonce, setNonce] = useState(0)

  const load = useCallback(() => {
    // Event-handler entry (Retry): reset then retrigger the effect below.
    setStage({ kind: 'loading' })
    setActionError(null)
    setApproved(false)
    setNonce((n) => n + 1)
  }, [])

  useEffect(() => {
    if (!open) return
    let cancelled = false
    getClient()
      .repositoryImport.listLocalCandidates()
      .then((candidates) => {
        if (!cancelled) setStage({ kind: 'candidates', candidates })
      })
      .catch((error: unknown) => {
        if (cancelled) return
        setStage({
          kind: 'error',
          error: error instanceof ClientError ? error : new ClientError('network', 'Repository discovery failed'),
        })
      })
    return () => {
      cancelled = true
    }
  }, [open, nonce])

  const inspect = async (candidate: RepositoryCandidate) => {
    setStage({ kind: 'inspecting', candidate })
    setActionError(null)
    try {
      const inspection = await getClient().repositoryImport.inspect(candidate.candidateId)
      setName(candidate.displayName)
      setApproved(false)
      setStage({ kind: 'review', candidate, inspection })
    } catch (error) {
      setActionError(error instanceof ClientError ? error.message : 'Inspection failed')
      void load()
    }
  }

  const register = async () => {
    if (stage.kind !== 'review' || !approved) return
    const { candidate, inspection } = stage
    setStage({ kind: 'registering', candidate, inspection })
    setActionError(null)
    try {
      const registration = await getClient().repositoryImport.register({
        candidateId: candidate.candidateId,
        name: name.trim() || candidate.displayName,
        inspectionDigest: inspection.inspectionDigest,
        approved: true,
      })
      setStage({ kind: 'done', registration, name: name.trim() || candidate.displayName })
    } catch (error) {
      setStage({ kind: 'review', candidate, inspection })
      setActionError(
        error instanceof ClientError
          ? `${error.message}${error.detail ? ` — ${error.detail}` : ''}`
          : 'Registration failed',
      )
    }
  }

  const close = (next: boolean) => {
    if (!next) setStage({ kind: 'loading' })
    onOpenChange(next)
  }

  return (
    <Drawer
      open={open}
      onOpenChange={close}
      title="Import a local repository"
      description="Discovery is limited to operator-allowlisted roots. Inspection is read-only — no repository code is executed."
      footer={
        stage.kind === 'review' ? (
          <Button onClick={() => void register()} disabled={!approved} data-testid="import-register">
            Register repository
          </Button>
        ) : stage.kind === 'done' ? (
          <>
            <Button variant="secondary" onClick={() => close(false)}>
              Close
            </Button>
            <Button
              onClick={() => {
                close(false)
                if (stage.kind === 'done') navigate(`/app/${stage.registration.instanceId}`)
              }}
              data-testid="import-open-application"
            >
              Open application
            </Button>
          </>
        ) : undefined
      }
    >
      {stage.kind === 'loading' || stage.kind === 'inspecting' || stage.kind === 'registering' ? (
        <div className="flex items-center gap-2 py-6 text-sm text-foreground-secondary">
          <Spinner className="size-4" />
          {stage.kind === 'loading'
            ? 'Discovering allowlisted repositories…'
            : stage.kind === 'inspecting'
              ? 'Inspecting read-only…'
              : 'Registering with exact approval…'}
        </div>
      ) : null}

      {stage.kind === 'error' ? (
        <ErrorState
          title="Repository discovery is unavailable"
          error={stage.error}
          onRetry={() => void load()}
        />
      ) : null}

      {stage.kind === 'candidates' ? (
        <div className="flex flex-col gap-2" data-testid="import-candidates">
          {actionError ? <InlineNotice tone="danger">{actionError}</InlineNotice> : null}
          {stage.candidates.length === 0 ? (
            <p className="py-4 text-sm text-foreground-secondary">
              No repositories were found under the operator-allowlisted roots. Ask the operator to allowlist a
              location before importing.
            </p>
          ) : (
            <ul className="flex flex-col gap-1.5">
              {stage.candidates.map((candidate) => (
                <li key={candidate.candidateId}>
                  <button
                    type="button"
                    onClick={() => void inspect(candidate)}
                    className="flex w-full items-center justify-between gap-2 rounded-md border border-border bg-surface px-3 py-2.5 text-left hover:bg-hover"
                    data-testid={`import-candidate-${candidate.displayName}`}
                  >
                    <span className="min-w-0">
                      <span className="block truncate text-sm font-medium text-foreground">{candidate.displayName}</span>
                      <span className="block truncate text-xs text-foreground-tertiary">{candidate.relativeLocation}</span>
                    </span>
                    <GitBranch className="size-4 shrink-0 text-foreground-tertiary" aria-hidden="true" />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      ) : null}

      {stage.kind === 'review' ? (
        <div className="flex flex-col gap-3" data-testid="import-review">
          {actionError ? <InlineNotice tone="danger">{actionError}</InlineNotice> : null}
          <dl className="flex flex-col gap-1.5 text-sm">
            <div className="flex gap-2">
              <dt className="w-28 shrink-0 text-foreground-secondary">Repository</dt>
              <dd className="min-w-0 truncate text-foreground">{stage.candidate.displayName}</dd>
            </div>
            <div className="flex gap-2">
              <dt className="w-28 shrink-0 text-foreground-secondary">Location</dt>
              <dd className="min-w-0 truncate text-foreground">{stage.inspection.source || stage.candidate.relativeLocation}</dd>
            </div>
            <div className="flex gap-2">
              <dt className="w-28 shrink-0 text-foreground-secondary">Branch</dt>
              <dd className="text-foreground">{stage.inspection.branch}</dd>
            </div>
            <div className="flex gap-2">
              <dt className="w-28 shrink-0 text-foreground-secondary">Commit</dt>
              <dd className="font-mono text-xs text-foreground">{stage.inspection.headCommit.slice(0, 12) || 'unknown'}</dd>
            </div>
            <div className="flex gap-2">
              <dt className="w-28 shrink-0 text-foreground-secondary">Working tree</dt>
              <dd className="text-foreground">{stage.inspection.dirty ? 'Dirty — uncommitted changes present' : 'Clean'}</dd>
            </div>
          </dl>

          {stage.inspection.findings.length > 0 ? (
            <ul className="flex flex-col gap-1" aria-label="Inspection findings">
              {stage.inspection.findings.map((finding) => (
                <li key={finding.code} className="flex items-start gap-1.5 text-xs">
                  {finding.severity === 'error' ? (
                    <CircleAlert className="mt-0.5 size-3.5 shrink-0 text-status-danger" aria-hidden="true" />
                  ) : (
                    <TriangleAlert className="mt-0.5 size-3.5 shrink-0 text-status-attention" aria-hidden="true" />
                  )}
                  <span className="text-foreground-secondary">{finding.message}</span>
                </li>
              ))}
            </ul>
          ) : null}

          {stage.inspection.findings.some((finding) => finding.severity === 'error') ? (
            <InlineNotice tone="danger">
              The inspection reported an error finding — registration must not proceed until it is resolved.
            </InlineNotice>
          ) : (
            <>
              <label className="flex flex-col gap-1 text-sm">
                <span className="text-foreground-secondary">Application name</span>
                <input
                  value={name}
                  onChange={(event) => setName(event.target.value)}
                  className="h-control rounded-sm border border-input bg-surface px-2 text-sm text-foreground"
                  data-testid="import-name"
                />
              </label>
              <label className="flex items-start gap-2 text-sm" data-testid="import-approval">
                <Checkbox
                  checked={approved}
                  onCheckedChange={(checked) => setApproved(checked === true)}
                  aria-label="Approve registration of the exact inspected repository"
                />
                <span className="text-foreground-secondary">
                  Register exactly this inspected repository (commit {stage.inspection.headCommit.slice(0, 12) || 'unknown'},
                  digest {stage.inspection.inspectionDigest.slice(0, 12)}…). If the repository changes, registration is
                  refused and a fresh inspection is required.
                </span>
              </label>
            </>
          )}
        </div>
      ) : null}

      {stage.kind === 'done' ? (
        <div className="flex flex-col gap-2" data-testid="import-done">
          <p className="text-sm text-foreground">
            <span className="font-medium">{stage.name}</span> is registered. A repository-import receipt was recorded;
            the repository itself was never modified.
          </p>
          {stage.registration.receiptId ? (
            <p className="font-mono text-xs text-foreground-tertiary">Receipt: {stage.registration.receiptId}</p>
          ) : null}
        </div>
      ) : null}
    </Drawer>
  )
}

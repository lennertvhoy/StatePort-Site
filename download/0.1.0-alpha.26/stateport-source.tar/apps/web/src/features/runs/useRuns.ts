/**
 * Single data owner for the governed Runs surface.
 *
 * Actions, engines, and history load as one keyed snapshot. Transitions bind
 * the exact instance and revision from the loaded run. Failures remain the
 * service's failures: this layer does not relabel a generic 400/409 as stale
 * and never retries a mutation implicitly.
 */
import { useCallback, useEffect, useRef, useState } from 'react'

import type {
  ExecutionEngine,
  GovernedAction,
  RunOperation,
  RunRecord,
} from '@/client'
import { getClient } from '@/client'
import { useCurrentInstance } from '@/shell/currentInstance'
import { invalidateInstanceCache } from '@/shell/data'
import { useSessionStore } from '@/state'

interface RunsSnapshot {
  key: string
  actions: GovernedAction[]
  engines: ExecutionEngine[]
  history: RunRecord[]
  error: unknown
}

export interface RunsState {
  status: 'loading' | 'ready' | 'error'
  loadError: unknown
  transitionError: unknown
  actions: GovernedAction[]
  engines: ExecutionEngine[]
  history: RunRecord[]
  activeRun: RunRecord | null
  busy: boolean
}

export interface RunsActions {
  refresh: () => void
  prepare: (input: {
    actionId: string
    engineId: string
    inputs: Record<string, unknown>
  }) => Promise<RunRecord | null>
  transition: (run: RunRecord, operation: RunOperation) => Promise<RunRecord | null>
  /** Approve the exact proposal (when still pending), then apply it. */
  applyProposal: (run: RunRecord) => Promise<RunRecord | null>
  selectRun: (run: RunRecord | null) => void
  dismissActiveRun: () => void
  clearTransitionError: () => void
}

export function useRuns(instanceId: string): RunsState & RunsActions {
  const [nonce, setNonce] = useState(0)
  const [snapshot, setSnapshot] = useState<RunsSnapshot | null>(null)
  const [activeRun, setActiveRun] = useState<RunRecord | null>(null)
  const [transitionError, setTransitionError] = useState<unknown>(null)
  const [busy, setBusy] = useState(false)
  // Governed transitions can change the instance projection server-side
  // (Learning progress, activity, approvals). Default context is a no-op when
  // rendered outside the app shell (tests).
  const { refresh: refreshInstanceContext } = useCurrentInstance()
  const requestKey = `${instanceId}#${nonce}`
  const currentRequestKey = useRef(requestKey)
  currentRequestKey.current = requestKey

  useEffect(() => {
    if (!instanceId) return
    let cancelled = false
    const client = getClient()
    Promise.all([
      client.runs.listActions(instanceId),
      client.runs.listEngines(),
      client.runs.getHistory(instanceId),
    ])
      .then(([actions, engines, history]) => {
        if (cancelled) return
        setSnapshot({ key: requestKey, actions, engines, history, error: null })
        setActiveRun((current) =>
          current ? (history.find((run) => run.id === current.id) ?? null) : null,
        )
      })
      .catch((error: unknown) => {
        if (!cancelled) {
          setSnapshot({ key: requestKey, actions: [], engines: [], history: [], error })
        }
      })
    return () => {
      cancelled = true
    }
  }, [instanceId, requestKey])

  const landed = snapshot?.key === requestKey ? snapshot : null
  const status = !landed ? 'loading' : landed.error ? 'error' : 'ready'

  const updateRun = useCallback(
    (run: RunRecord) => {
      if (currentRequestKey.current !== requestKey) return
      setActiveRun(run)
      setSnapshot((current) => {
        if (!current || current.key !== requestKey) return current
        return {
          ...current,
          history: [run, ...current.history.filter((item) => item.id !== run.id)],
        }
      })
    },
    [requestKey],
  )

  const refresh = useCallback(() => {
    setTransitionError(null)
    setNonce((value) => value + 1)
  }, [])

  const prepare = useCallback(
    async (input: {
      actionId: string
      engineId: string
      inputs: Record<string, unknown>
    }): Promise<RunRecord | null> => {
      setBusy(true)
      setTransitionError(null)
      const releaseOperationsMutation = useSessionStore.getState().beginOperationsMutation()
      try {
        const run = await getClient().runs.prepare(instanceId, input)
        updateRun(run)
        return run
      } catch (error: unknown) {
        setTransitionError(error)
        return null
      } finally {
        releaseOperationsMutation()
        setBusy(false)
      }
    },
    [instanceId, updateRun],
  )

  const transition = useCallback(
    async (run: RunRecord, operation: RunOperation): Promise<RunRecord | null> => {
      setBusy(true)
      setTransitionError(null)
      const releaseOperationsMutation = useSessionStore.getState().beginOperationsMutation()
      try {
        const next = await getClient().runs.transition(run.id, operation, {
          expectedInstanceId: run.instanceId,
          expectedRevision: run.revision,
        })
        updateRun(next)
        // Every transition here is a governed mutation of the run. Drop the
        // shell's cached projection of the affected instance so surfaces like
        // the Learning overview re-read truth (no polling); re-read the live
        // app context when the transition belongs to this shell's instance.
        invalidateInstanceCache(next.instanceId)
        if (next.instanceId === instanceId) refreshInstanceContext()
        return next
      } catch (error: unknown) {
        setTransitionError(error)
        return null
      } finally {
        releaseOperationsMutation()
        setBusy(false)
      }
    },
    [instanceId, refreshInstanceContext, updateRun],
  )

  const applyProposal = useCallback(
    async (run: RunRecord): Promise<RunRecord | null> => {
      const approved = run.status === 'state_change_proposed' ? await transition(run, 'proposal-approve') : run
      if (!approved || approved.status !== 'state_change_approved') return approved
      return transition(approved, 'apply')
    },
    [transition],
  )

  const selectRun = useCallback((run: RunRecord | null) => {
    setTransitionError(null)
    setActiveRun(run)
  }, [])
  const dismissActiveRun = useCallback(() => {
    setTransitionError(null)
    setActiveRun(null)
  }, [])
  const clearTransitionError = useCallback(() => setTransitionError(null), [])

  return {
    status,
    loadError: landed?.error ?? null,
    transitionError,
    actions: landed?.actions ?? [],
    engines: landed?.engines ?? [],
    history: landed?.history ?? [],
    activeRun,
    busy,
    refresh,
    prepare,
    transition,
    applyProposal,
    selectRun,
    dismissActiveRun,
    clearTransitionError,
  }
}
